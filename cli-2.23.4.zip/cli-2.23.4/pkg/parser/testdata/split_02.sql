

CREATE UNIQUE INDEX "block_uuid_uindex"
    ON "blocks"."block" (uuid);