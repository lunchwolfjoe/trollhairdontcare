

CREATE INDEX "placement_index_index"
    ON "blocks".placement (index);