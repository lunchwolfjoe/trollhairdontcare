

CREATE TABLE "blocks"."location_hash"
(
    location_name CHARACTER VARYING PRIMARY KEY  NOT NULL,
    hash          CHARACTER VARYING              NOT NULL
);