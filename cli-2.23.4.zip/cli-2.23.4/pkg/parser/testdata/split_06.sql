

CREATE INDEX "placement_scope_path_index"
    ON "blocks".placement (scope_path);