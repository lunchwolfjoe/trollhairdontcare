

CREATE INDEX "placement_location_name_index_index"
    ON "blocks".placement (location_name, index);