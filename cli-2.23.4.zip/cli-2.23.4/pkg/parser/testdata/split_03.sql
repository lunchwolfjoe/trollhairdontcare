

CREATE INDEX "enabled_index"
    ON "blocks"."block" (enabled);